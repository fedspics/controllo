#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/msg/pose_stamped.hpp>

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("tiago_grasp_test");

  auto logger = node->get_logger();

  // Inizializza MoveGroup per TIAGo: gruppo braccio + torso (nome convenzionale: "arm_torso")
  moveit::planning_interface::MoveGroupInterface move_group(node, "arm_torso");
  move_group.setPoseReferenceFrame("base_link");
  move_group.setPlannerId("RRTConnectkConfigDefault");
  move_group.setPlanningTime(5.0);

  RCLCPP_INFO(logger, "Planning frame: '%s'", move_group.getPlanningFrame().c_str());
  RCLCPP_INFO(logger, "End effector link: '%s'", move_group.getEndEffectorLink().c_str());

  // Definisci la pose target basata sulla posizione pubblicata
  geometry_msgs::msg::Pose target_pose;
  target_pose.orientation.w = 1.0;  // orientazione neutra
  target_pose.position.x = 1.527427006058215;
  target_pose.position.y = 0.9790507645260393;
  target_pose.position.z = 0.7451756436273517;

  move_group.setPoseTarget(target_pose);

  // Pianiﬁca il percorso
  moveit::planning_interface::MoveGroupInterface::Plan plan;
  bool success = (move_group.plan(plan) == moveit::core::MoveItErrorCode::EXECUTE_SUCCESS);

  if (success)
  {
    RCLCPP_INFO(logger, "Pianificazione riuscita, esecuzione...");
    move_group.execute(plan);
    RCLCPP_INFO(logger, "Movimento completato.");
  }
  else
  {
    RCLCPP_ERROR(logger, "Pianificazione fallita: oggetto non raggiungibile senza muovere base.");
  }

  rclcpp::shutdown();
  return 0;
}

