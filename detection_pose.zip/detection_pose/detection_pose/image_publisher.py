import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np

class ImagePublisher(Node):
    def __init__(self):
        super().__init__('image_publisher')
        self.publisher_ = self.create_publisher(Image, 'image_topic', 10)
        self.timer = self.create_timer(1.0, self.publish_image)  # Timer per pubblicare ogni secondo
        self.bridge = CvBridge()

        # Apri la fotocamera integrata (modifica l'indice se non è la fotocamera predefinita)
        self.cap = cv2.VideoCapture(0)

        if not self.cap.isOpened():
            self.get_logger().error("Impossibile aprire la fotocamera!")
            return

    def publish_image(self):
        # Leggi un frame dalla fotocamera
        ret, frame = self.cap.read()

        if not ret:
            self.get_logger().error("Errore nel leggere il frame dalla fotocamera!")
            return

        # Verifica che il frame sia un numpy array
        if not isinstance(frame, np.ndarray):
            self.get_logger().error("Il frame non è un numpy array!")
            return

        try:
            # Converte il frame da OpenCV a ROS2 Image message
            img_msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
            self.publisher_.publish(img_msg)
            self.get_logger().info('Immagine pubblicata!')
        except Exception as e:
            self.get_logger().error(f"Errore durante la conversione dell'immagine: {e}")

    def __del__(self):
        # Rilascia la fotocamera quando il nodo viene distrutto
        if self.cap.isOpened():
            self.cap.release()

def main(args=None):
    rclpy.init(args=args)
    image_publisher = ImagePublisher()
    rclpy.spin(image_publisher)
    image_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

