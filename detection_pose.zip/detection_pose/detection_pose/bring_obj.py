#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from moveit_commander.robot_trajectory import RobotTrajectory
from moveit_commander import PlanningSceneInterface, RobotCommander, MoveGroupCommander
import tf2_ros
import geometry_msgs.msg
import math

class BowlScanNode(Node):
    def __init__(self):
        super().__init__('bowl_scan_node')
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)
        self.robot = RobotCommander()
        self.scene = PlanningSceneInterface()
        self.group = MoveGroupCommander("manipulator")
        self.bowl_position = None  # Posizione della bowl in base_link

    def bowl_position_callback(self, msg):
        """Callback per ricevere la posizione della bowl."""
        self.bowl_position = msg.pose.position
        self.check_graspability()

    def check_graspability(self):
        """Verifica se l'oggetto è afferrabile senza muovere il robot."""
        if self.bowl_position is None:
            self.get_logger().warn("Posizione della bowl non disponibile.")
            return

        # Trasforma la posizione della bowl in base_link
        try:
            transform = self.tf_buffer.lookup_transform("base_link", "camera_link", rclpy.time.Time())
            bowl_position_in_base = self.transform_position(self.bowl_position, transform)
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException) as e:
            self.get_logger().warn(f"Errore nella trasformazione: {e}")
            return

        # Crea un obiettivo di posa per l'IK
        pose_goal = geometry_msgs.msg.Pose()
        pose_goal.position = bowl_position_in_base
        pose_goal.orientation.w = 1.0  # Orientamento neutro

        # Calcola la cinematica inversa
        self.group.set_pose_target(pose_goal)
        plan = self.group.plan()

        # Verifica se esiste una soluzione valida
        if plan.joint_trajectory.points:
            self.get_logger().info("Posizione afferrabile senza muovere il robot.")
        else:
            self.get_logger().warn("Posizione NON afferrabile senza muovere il robot.")

    def transform_position(self, position, transform):
        """Trasforma una posizione data in un altro frame."""
        point = geometry_msgs.msg.PointStamped()
        point.header.frame_id = "camera_link"
        point.header.stamp = rclpy.time.Time()
        point.point = position
        transformed_point = self.tf_buffer.transform(point, "base_link")
        return transformed_point.point

def main(args=None):
    rclpy.init(args=args)
    node = BowlScanNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

