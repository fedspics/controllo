#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ultralytics import YOLO
import math
from control_msgs.action import FollowJointTrajectory
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from rclpy.action import ActionClient
from visualization_msgs.msg import Marker
from geometry_msgs.msg import PointStamped
import tf2_ros
import tf2_geometry_msgs
import numpy as np

class BowlScanNode(Node):
    def __init__(self):
        super().__init__('bowl_scan_node')

        # Set use_sim_time = true for simulation time

        self.set_parameters([rclpy.Parameter('use_sim_time', rclpy.Parameter.Type.BOOL, True)])

        self.bridge = CvBridge()
        self.model = YOLO('yolov8s.pt')

        self.image_sub = self.create_subscription(
            Image,
            '/head_front_camera/rgb/image_raw',
            self.image_callback,
            10
        )
        self.depth_sub = self.create_subscription(
            Image,
            '/head_front_camera/depth/image_raw',
            self.depth_callback,
            10
        )

        self.marker_pub = self.create_publisher(Marker, '/bowl_marker', 10)
        self.position_pub = self.create_publisher(PointStamped, '/bowl_position', 10)

        self.head_action_client = ActionClient(self, FollowJointTrajectory, '/head_controller/follow_joint_trajectory')
        self.head_joints = ['head_1_joint', 'head_2_joint']

        self.latest_frame = None
        self.latest_depth = None
        self.found = False
        self.moving = False
        self.scanning = False

        self.scan_angles = []
        pan_angles = [-60, -30, 0, 30, 60]
        tilt_angles = [0, -30]

        for pan_deg in pan_angles:
            for tilt_deg in tilt_angles:
                pan_rad = math.radians(pan_deg)
                tilt_rad = math.radians(tilt_deg)
                self.scan_angles.append((pan_rad, tilt_rad))

        self.current_idx = 0
        self.images_buffer = []
        self.images_needed = 5
        self.buffer_timer = None

        # Timers
        self.scan_timer = self.create_timer(1.0, self.scan_step)
        self.marker_publish_timer = self.create_timer(0.1, self.publish_marker_timer_callback)
        self.position_publish_timer = self.create_timer(0.1, self.publish_position_timer_callback)

        self.bowl_position = None

        # TF2 buffer and listener
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Wait until simulated time has started
        self.get_logger().info('Waiting for simulated time to start...')
        self.wait_for_sim_time()

    def wait_for_sim_time(self):
        # Spin until clock time > 0
        while rclpy.ok():
            now = self.get_clock().now()
            if now.nanoseconds > 0:
                self.get_logger().info(f'Simulated time started: {now.nanoseconds}')
                break
            rclpy.spin_once(self, timeout_sec=0.1)

    def image_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        self.latest_frame = frame
        if self.scanning:
            self.images_buffer.append(frame)
            if len(self.images_buffer) > self.images_needed:
                self.images_buffer.pop(0)

    def depth_callback(self, msg):
        depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
        self.latest_depth = depth_image

    def scan_step(self):
        if self.found:
            self.get_logger().info('Bowl già trovata. Scansione terminata.')
            return

        if self.moving or self.scanning:
            return

        if not self.head_action_client.server_is_ready():
            self.get_logger().info('Server della testa non pronto.')
            return

        if self.current_idx >= len(self.scan_angles):
            self.get_logger().info('Scansione completata, bowl non trovata.')
            self.scan_timer.cancel()
            return

        pan, tilt = self.scan_angles[self.current_idx]
        self.get_logger().info(f'Spostamento testa a PAN={math.degrees(pan):.1f}°, TILT={math.degrees(tilt):.1f}°')
        self.send_head_trajectory(pan, tilt, 2.0)
        self.moving = True
        self.current_idx += 1

    def send_head_trajectory(self, pan, tilt, time_s=2.0):
        traj = JointTrajectory()
        traj.joint_names = self.head_joints
        point = JointTrajectoryPoint()
        point.positions = [pan, tilt]
        point.time_from_start.sec = int(time_s)
        point.time_from_start.nanosec = int((time_s - int(time_s)) * 1e9)
        traj.points = [point]

        goal_msg = FollowJointTrajectory.Goal()
        goal_msg.trajectory = traj

        future = self.head_action_client.send_goal_async(goal_msg)
        future.add_done_callback(self.on_goal_response)

    def on_goal_response(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().warn('Movimento testa rifiutato.')
            self.moving = False
            return

        self.get_logger().info('Movimento testa accettato. In attesa del completamento...')
        goal_handle.get_result_async().add_done_callback(self.on_motion_complete)

    def on_motion_complete(self, future):
        self.get_logger().info('Movimento testa completato.')
        self.moving = False

        self.scanning = True
        self.images_buffer = []

        if self.buffer_timer is not None:
            self.buffer_timer.cancel()
        self.buffer_timer = self.create_timer(0.5, self.process_buffered_images)

    def process_buffered_images(self):
        if len(self.images_buffer) < self.images_needed:
            self.get_logger().info(f'Aspetto immagini, raccolte {len(self.images_buffer)}/{self.images_needed}')
            return

        if self.buffer_timer is not None:
            self.buffer_timer.cancel()
            self.buffer_timer = None

        self.get_logger().info(f'Elaborazione di {len(self.images_buffer)} immagini per riconoscimento.')
        frame = self.images_buffer[-1]
        results = self.model(frame)

        if not results or len(results[0].boxes) == 0:
            self.get_logger().info('Nessun oggetto rilevato.')
        else:
            for box in results[0].boxes:
                cls = int(box.cls[0])
                name = self.model.names[cls]
                conf = float(box.conf[0])
                self.get_logger().info(f'Oggetto: {name} - Confidenza: {conf:.2f}')
                if name == 'bowl':
                    self.get_logger().info('BOWL trovata! Calcolo posizione 3D...')

                    pos3d = self.calculate_3d_position(box)
                    if pos3d is not None:
                        self.get_logger().info(f'Posizione 3D bowl: X={pos3d[0]:.3f}, Y={pos3d[1]:.3f}, Z={pos3d[2]:.3f}')
                        self.bowl_position = pos3d
                    else:
                        self.get_logger().warn('Depth o info camera non disponibili, salto elaborazione posizione 3D.')

                    self.found = True
                    self.scanning = False
                    self.scan_timer.cancel()
                    return

        self.scanning = False

    def calculate_3d_position(self, box):
        if self.latest_depth is None or self.latest_frame is None:
            return None

        x1, y1, x2, y2 = map(int, box.xyxy[0])
        cx = (x1 + x2) // 2
        cy = (y1 + y2) // 2

        depth = float(self.latest_depth[cy, cx])
        if np.isnan(depth) or depth <= 0.0:
            return None

        # Camera intrinsics (esempio, sostituire con quelli reali)
        fx = 610.0
        fy = 610.0
        cx_cam = 320.0
        cy_cam = 240.0

        X = (cx - cx_cam) * depth / fx
        Y = (cy - cy_cam) * depth / fy
        Z = depth

        return (X, Y, Z)

    def publish_position_timer_callback(self):
        if self.bowl_position is None:
            return

        source_frame = 'head_front_camera_depth_optical_frame'
        target_frame = 'base_link'

        point_stamped = PointStamped()
        point_stamped.header.frame_id = source_frame
        point_stamped.header.stamp = self.get_clock().now().to_msg()
        point_stamped.point.x = float(self.bowl_position[0])
        point_stamped.point.y = float(self.bowl_position[1])
        point_stamped.point.z = float(self.bowl_position[2])

        try:
            # Usa time= rclpy.time.Time() per ultimo disponibile, evita errori extrapolazione
            transform = self.tf_buffer.lookup_transform(
                target_frame,
                source_frame,
                rclpy.time.Time()
            )
            point_base_link = tf2_geometry_msgs.do_transform_point(point_stamped, transform)
            self.position_pub.publish(point_base_link)
        except Exception as e:
            self.get_logger().warn(f'Errore nella trasformazione tf2: {e}')

    def publish_marker_timer_callback(self):
        if self.bowl_position is None:
            return

        marker = Marker()
        marker.header.frame_id = 'head_front_camera_depth_optical_frame'
        marker.header.stamp = self.get_clock().now().to_msg()
        marker.ns = 'bowl'
        marker.id = 0
        marker.type = Marker.SPHERE
        marker.action = Marker.ADD
        marker.pose.position.x = float(self.bowl_position[0])
        marker.pose.position.y = float(self.bowl_position[1])
        marker.pose.position.z = float(self.bowl_position[2])
        marker.pose.orientation.w = 1.0
        marker.scale.x = 0.05
        marker.scale.y = 0.05
        marker.scale.z = 0.05
        marker.color.a = 1.0
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0

        self.marker_pub.publish(marker)

def main(args=None):
    rclpy.init(args=args)
    node = BowlScanNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

