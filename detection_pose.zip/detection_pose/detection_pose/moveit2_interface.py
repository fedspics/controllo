#!/usr/bin/env python3
from moveit_commander import MoveGroupCommander, RobotCommander, PlanningSceneInterface
from geometry_msgs.msg import PoseStamped
import time

class MoveIt2Interface:
    def __init__(self, node):
        self.node = node
        self.robot = RobotCommander()
        self.scene = PlanningSceneInterface()
        self.group = MoveGroupCommander("arm")  # o il nome del tuo gruppo

        self.gripper_group = MoveGroupCommander("gripper")  # gruppo per il gripper

        node.get_logger().info("MoveIt2Interface inizializzato")

    def go_to_pose(self, pose: PoseStamped):
        self.group.set_pose_target(pose)
        plan = self.group.go(wait=True)
        self.group.stop()
        self.group.clear_pose_targets()
        return plan

    def open_gripper(self):
        joint_goal = self.gripper_group.get_current_joint_values()
        joint_goal[0] = 0.04  # posizione aperta tipica per Tiago
        self.gripper_group.go(joint_goal, wait=True)
        self.gripper_group.stop()

    def close_gripper(self):
        joint_goal = self.gripper_group.get_current_joint_values()
        joint_goal[0] = 0.0  # posizione chiusa
        self.gripper_group.go(joint_goal, wait=True)
        self.gripper_group.stop()

